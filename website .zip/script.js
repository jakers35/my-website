document.addEventListener('DOMContentLoaded', () => {
  console.log('Website is loaded and ready!');
  // Add any JavaScript functionality here
});
